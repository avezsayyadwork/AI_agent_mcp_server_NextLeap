async function run() {
  const url = "https://itunes.apple.com/us/rss/customerreviews/id=661139481/sortBy=mostRecent/json";
  try {
    const res = await fetch(url);
    const json = await res.json();
    console.log("Feed Keys:", Object.keys(json.feed));
    console.log("Feed Details:", JSON.stringify(json.feed, null, 2));
  } catch (e) {
    console.error(e);
  }
}
run();
