async function run() {
  const url = "https://itunes.apple.com/us/rss/customerreviews/page=1/id=661139481/sortBy=mostRecent/json";
  console.log(`Fetching from: ${url}`);
  try {
    const res = await fetch(url, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36'
      }
    });
    console.log(`Status: ${res.status}`);
    const text = await res.text();
    console.log(`Response length: ${text.length}`);
    if (text.startsWith('{')) {
      const json = JSON.parse(text);
      if (json.feed && json.feed.entry) {
        console.log(`Found ${json.feed.entry.length} review entries.`);
        console.log('Sample review:', JSON.stringify(json.feed.entry[0], null, 2));
      } else {
        console.log('No feed or entries found in JSON:', Object.keys(json));
      }
    } else {
      console.log('Response is not JSON:', text.substring(0, 200));
    }
  } catch (error) {
    console.error('Error during fetch:', error);
  }
}

run();
