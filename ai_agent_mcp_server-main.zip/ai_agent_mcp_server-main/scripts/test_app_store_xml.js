async function run() {
  const url = "https://itunes.apple.com/us/rss/customerreviews/id=661139481/xml";
  console.log(`Fetching XML from: ${url}`);
  try {
    const res = await fetch(url);
    console.log(`Status: ${res.status}`);
    const text = await res.text();
    console.log(`Response length: ${text.length}`);
    console.log("Snippet:", text.substring(0, 1000));
  } catch (e) {
    console.error(e);
  }
}
run();
