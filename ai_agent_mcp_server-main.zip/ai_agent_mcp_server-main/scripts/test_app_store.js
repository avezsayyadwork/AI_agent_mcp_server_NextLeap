import appStore from 'app-store-scraper';

async function test() {
  const apps = [
    { name: 'Wise', id: 661139481 },
    { name: 'Instagram', id: 389801252 },
    { name: 'YouTube', id: 544007664 },
    { name: 'Revolut', id: 932493382 }
  ];

  for (const app of apps) {
    console.log(`Testing ${app.name} (${app.id})...`);
    try {
      const res = await appStore.reviews({
        id: app.id,
        country: 'us',
        page: 1
      });
      console.log(`-> Fetched ${res.length} reviews`);
      if (res.length > 0) {
        console.log('Sample review:', res[0]);
      }
    } catch (e) {
      console.error(`-> Error: ${e.message}`);
    }
  }
}

test();
