import { ReviewImporter } from '../src/importer/importer.js';
import fs from 'fs';
import path from 'path';

// Setup file paths
const INPUT_FILE = path.resolve('data/actual_reviews.json');
const OUTPUT_JSON = path.resolve('data/normalized_reviews.json');
const PLAY_STORE_CSV = path.resolve('data/normalized_play_store_reviews.csv');
const APP_STORE_CSV = path.resolve('data/normalized_app_store_reviews.csv');

function saveToCsv(reviews: any[], filePath: string) {
  const headers = ['source', 'rating', 'title', 'text', 'date', 'version'];
  const csvRows = [headers.join(',')];
  for (const review of reviews) {
    const row = headers.map(header => {
      let val = review[header] || '';
      // Escape quotes
      val = val.toString().replace(/"/g, '""');
      return `"${val}"`;
    });
    csvRows.push(row.join(','));
  }
  fs.writeFileSync(filePath, csvRows.join('\n'), 'utf-8');
}

async function main() {
  const importer = new ReviewImporter();
  
  console.log(`Reading and validating reviews from ${INPUT_FILE}...`);
  // importReviews automatically parses JSON and validates against Zod ReviewSchema
  const validReviews = importer.importReviews(INPUT_FILE);
  
  // Filter for last 12 weeks
  const referenceDate = new Date('2026-07-16T12:00:00Z'); // Using current system context reference date
  console.log(`Filtering reviews within the last 12 weeks relative to ${referenceDate.toISOString()}...`);
  const normalizedReviews = importer.filterReviewsByWeeks(validReviews, 12, referenceDate);
  
  console.log(`Total normalized reviews: ${normalizedReviews.length}`);
  
  // Write normalized JSON
  fs.writeFileSync(OUTPUT_JSON, JSON.stringify(normalizedReviews, null, 2), 'utf-8');
  console.log(`Saved normalized reviews to: ${OUTPUT_JSON}`);
  
  // Separate into Play Store and App Store and save to CSV
  const playReviews = normalizedReviews.filter(r => r.source === 'Play Store');
  const appReviews = normalizedReviews.filter(r => r.source === 'App Store');
  
  saveToCsv(playReviews, PLAY_STORE_CSV);
  saveToCsv(appReviews, APP_STORE_CSV);
  
  console.log(`Saved normalized Play Store reviews CSV (${playReviews.length} entries) to: ${PLAY_STORE_CSV}`);
  console.log(`Saved normalized App Store reviews CSV (${appReviews.length} entries) to: ${APP_STORE_CSV}`);
}

main().catch(err => {
  console.error("Failed to run normalization:", err);
});
