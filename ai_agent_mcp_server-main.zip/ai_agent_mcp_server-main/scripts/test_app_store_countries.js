async function run() {
  const countries = ['us', 'gb', 'ca', 'in', 'de'];
  const appId = 661139481; // Wise
  for (const country of countries) {
    const url = `https://itunes.apple.com/${country}/rss/customerreviews/id=${appId}/sortBy=mostRecent/json`;
    console.log(`Testing country: ${country}...`);
    try {
      const res = await fetch(url, {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
        }
      });
      const json = await res.json();
      if (json.feed && json.feed.entry) {
        console.log(`-> Success! Found ${json.feed.entry.length} reviews for country ${country}.`);
        return;
      } else {
        console.log(`-> Empty feed for country ${country}.`);
      }
    } catch (e) {
      console.log(`-> Error for country ${country}: ${e.message}`);
    }
  }
}
run();
