---
name: Luminous Obsidian
colors:
  surface: '#0b1326'
  surface-dim: '#0b1326'
  surface-bright: '#31394d'
  surface-container-lowest: '#060e20'
  surface-container-low: '#131b2e'
  surface-container: '#171f33'
  surface-container-high: '#222a3d'
  surface-container-highest: '#2d3449'
  on-surface: '#dae2fd'
  on-surface-variant: '#c7c4d7'
  inverse-surface: '#dae2fd'
  inverse-on-surface: '#283044'
  outline: '#908fa0'
  outline-variant: '#464554'
  surface-tint: '#c0c1ff'
  primary: '#c0c1ff'
  on-primary: '#1000a9'
  primary-container: '#8083ff'
  on-primary-container: '#0d0096'
  inverse-primary: '#494bd6'
  secondary: '#4edea3'
  on-secondary: '#003824'
  secondary-container: '#00a572'
  on-secondary-container: '#00311f'
  tertiary: '#ffb95f'
  on-tertiary: '#472a00'
  tertiary-container: '#ca8100'
  on-tertiary-container: '#3e2400'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#e1e0ff'
  primary-fixed-dim: '#c0c1ff'
  on-primary-fixed: '#07006c'
  on-primary-fixed-variant: '#2f2ebe'
  secondary-fixed: '#6ffbbe'
  secondary-fixed-dim: '#4edea3'
  on-secondary-fixed: '#002113'
  on-secondary-fixed-variant: '#005236'
  tertiary-fixed: '#ffddb8'
  tertiary-fixed-dim: '#ffb95f'
  on-tertiary-fixed: '#2a1700'
  on-tertiary-fixed-variant: '#653e00'
  background: '#0b1326'
  on-background: '#dae2fd'
  surface-variant: '#2d3449'
typography:
  display-lg:
    fontFamily: Outfit
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Outfit
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Outfit
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.05em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 4px
  container-max: 1440px
  gutter: 24px
  margin-desktop: 40px
  margin-mobile: 16px
---

## Brand & Style
The design system is engineered for high-performance SaaS environments, specifically tailored for data-heavy sentiment analysis and feedback loops. The brand personality is authoritative yet ethereal, blending the precision of enterprise software with a futuristic, tactile aesthetic.

The chosen style is a refined **Glassmorphism**, leveraging high-density background blurs, sub-pixel borders, and subtle glow effects to create a sense of depth and focus within a sleek dark-mode environment. The UI should evoke a sense of "intelligence under the hood," making complex data processing feel effortless and premium.

## Colors
This design system utilizes a deep-space palette to maximize contrast for its glassmorphic elements. 

- **Primary (Indigo):** Used for core actions, focus states, and the primary "Run Pipeline" glow.
- **Sentiment Spectrum:** Emerald is reserved for positive data clusters, Amber for neutral/mixed, and Rose for critical/negative alerts.
- **Surface Strategy:** The background is a solid `#0F172A`. All interactive surfaces use semi-transparent white or primary overlays (ranging from 4% to 12% opacity) combined with `backdrop-filter: blur(12px)`.

## Typography
The typography strategy pairs the geometric, modern clarity of **Outfit** for headings with the systematic reliability of **Inter** for UI elements and data display. 

Large display titles should use tighter letter-spacing to maintain a "tight" professional look. Labels and metadata should use slightly increased tracking and a semi-bold weight for legibility against blurred backgrounds.

## Layout & Spacing
The layout follows a **Fluid Grid** model with a 12-column structure for desktop. To maintain the "Glass" effect without visual clutter, whitespace is used aggressively to separate functional zones.

- **Desktop:** 12 columns, 24px gutters, 40px outer margins.
- **Tablet:** 8 columns, 16px gutters, 24px outer margins.
- **Mobile:** 4 columns, 16px gutters, 16px outer margins.

Spacing increments are strictly based on a 4px scale, ensuring mathematical harmony across all components.

## Elevation & Depth
Depth is not communicated via traditional shadows, but through **Tonal Translucency** and **Inner Glows**.

- **Level 1 (Base):** Deep Slate solid color.
- **Level 2 (Cards/Sidebar):** White at 6% opacity + 16px Backdrop Blur + 1px border at 10% white opacity.
- **Level 3 (Modals/Popovers):** White at 12% opacity + 24px Backdrop Blur + 1px border at 20% white opacity.
- **Active Accents:** Elements like the primary button utilize a `box-shadow` with a large spread (20px+) using the primary indigo color at 30% opacity to simulate a neon glow.

## Shapes
The design system uses a "Rounded" language to soften the technical nature of the data. 

- **Standard Elements:** 8px (0.5rem) radius for cards and inputs.
- **Large Components:** 16px (1rem) for main dashboard containers.
- **Interactive Triggers:** Buttons and Chips use a fully rounded (Pill) shape to distinguish them from structural layout elements.

## Components
- **Primary "Run Pipeline" Button:** A pill-shaped component with an Indigo gradient background. It features a `drop-shadow` glow and an animated "pulse" on hover to indicate system readiness.
- **Glassmorphic Cards:** Container background: `rgba(255, 255, 255, 0.05)`. Border: `1px solid rgba(255, 255, 255, 0.1)`. No traditional shadow; depth is achieved via the blur.
- **Sentiment Badges:** Soft, semi-transparent fills using the accent colors (Emerald, Amber, Rose) at 15% opacity with high-contrast text in the same hue.
- **Sidebar Navigation:** A fixed vertical bar using a darker glass effect (`rgba(0, 0, 0, 0.2)` blur). Icons are thin-stroke (1.5px) outlines. Active states are indicated by a vertical indigo "pulse" line on the leading edge.
- **Star Rating Bars:** Instead of traditional stars, use segmented horizontal bars. Filled segments use the Primary Indigo; empty segments use `rgba(255, 255, 255, 0.1)`.
- **Input Fields:** Bottom-border only or very light glass fills to maintain a clean, "thin" interface. Focus state triggers a subtle glow on the border.