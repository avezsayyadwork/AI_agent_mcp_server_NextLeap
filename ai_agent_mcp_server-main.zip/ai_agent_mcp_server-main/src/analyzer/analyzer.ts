import { Review } from '../importer/importer.js';

export interface WeeklyPulseReport {
  meta: {
    weekEnding: string;
    totalReviewsAnalyzed: number;
  };
  themes: {
    name: string;
    sentiment: string;
    percentage: number;
  }[];
  verbatimQuotes: string[];
  actionIdeas: string[];
}

export interface RequestLog {
  timestamp: number;
  tokens: number;
}

export class LlamaRateLimiter {
  private history: RequestLog[] = [];

  private cleanHistory() {
    const now = Date.now();
    this.history = this.history.filter(log => now - log.timestamp < 24 * 60 * 60 * 1000);
  }

  private getStats(windowMs: number): { requests: number; tokens: number } {
    const now = Date.now();
    let requests = 0;
    let tokens = 0;
    for (const log of this.history) {
      if (now - log.timestamp < windowMs) {
        requests++;
        tokens += log.tokens;
      }
    }
    return { requests, tokens };
  }

  async waitForQuota(tokenEstimate: number): Promise<void> {
    while (true) {
      this.cleanHistory();
      const now = Date.now();

      const minuteStats = this.getStats(60 * 1000);
      const dailyStats = this.getStats(24 * 60 * 60 * 1000);

      // Check RPM (30)
      if (minuteStats.requests >= 30) {
        const oldestInMinute = this.history.find(log => now - log.timestamp < 60 * 1000);
        const waitMs = oldestInMinute ? (oldestInMinute.timestamp + 60 * 1000) - now : 1000;
        console.log(`[Rate Limiter] RPM limit reached. Delaying for ${waitMs}ms...`);
        await new Promise(resolve => setTimeout(resolve, Math.max(waitMs, 100)));
        continue;
      }

      // Check TPM (1000)
      if (minuteStats.tokens + tokenEstimate > 1000 && minuteStats.tokens > 0) {
        const oldestInMinute = this.history.find(log => now - log.timestamp < 60 * 1000);
        const waitMs = oldestInMinute ? (oldestInMinute.timestamp + 60 * 1000) - now : 1000;
        console.log(`[Rate Limiter] TPM limit reached (Current window tokens: ${minuteStats.tokens}, Estimate: ${tokenEstimate}). Delaying for ${waitMs}ms...`);
        await new Promise(resolve => setTimeout(resolve, Math.max(waitMs, 100)));
        continue;
      }

      // Check RPD (12000)
      if (dailyStats.requests >= 12000) {
        const oldestInDay = this.history[0];
        const waitMs = oldestInDay ? (oldestInDay.timestamp + 24 * 60 * 60 * 1000) - now : 60000;
        console.log(`[Rate Limiter] RPD limit reached. Delaying for ${waitMs}ms...`);
        await new Promise(resolve => setTimeout(resolve, Math.min(waitMs, 5000)));
        continue;
      }

      // Check TPD (100000)
      if (dailyStats.tokens + tokenEstimate > 100000 && dailyStats.tokens > 0) {
        const oldestInDay = this.history.find(log => now - log.timestamp < 24 * 60 * 60 * 1000);
        const waitMs = oldestInDay ? (oldestInDay.timestamp + 24 * 60 * 60 * 1000) - now : 60000;
        console.log(`[Rate Limiter] TPD limit reached (Current daily tokens: ${dailyStats.tokens}, Estimate: ${tokenEstimate}). Delaying for ${waitMs}ms...`);
        await new Promise(resolve => setTimeout(resolve, Math.min(waitMs, 5000)));
        continue;
      }

      break;
    }
  }

  recordRequest(tokens: number) {
    this.history.push({
      timestamp: Date.now(),
      tokens
    });
  }

  clear() {
    this.history = [];
  }

  getHistory(): RequestLog[] {
    return this.history;
  }
}

export function sampleReviews(reviews: Review[], targetSize: number): Review[] {
  if (reviews.length <= targetSize) {
    return [...reviews];
  }

  const groups: Record<string, Review[]> = {};
  for (const review of reviews) {
    const key = `${review.source}_${review.rating}`;
    if (!groups[key]) {
      groups[key] = [];
    }
    groups[key].push(review);
  }

  const groupKeys = Object.keys(groups);
  const totalReviews = reviews.length;

  const allocations = groupKeys.map(key => {
    const groupSize = groups[key].length;
    const exact = (groupSize / totalReviews) * targetSize;
    const floor = Math.floor(exact);
    const remainder = exact - floor;
    return { key, floor, remainder, target: floor };
  });

  let allocated = allocations.reduce((sum, a) => sum + a.target, 0);
  const remaining = targetSize - allocated;

  if (remaining > 0) {
    allocations.sort((a, b) => b.remainder - a.remainder);
    for (let i = 0; i < remaining; i++) {
      allocations[i].target += 1;
    }
  }

  const sampledReviews: Review[] = [];
  for (const alloc of allocations) {
    const groupReviews = groups[alloc.key];
    groupReviews.sort((a, b) => b.text.length - a.text.length);
    sampledReviews.push(...groupReviews.slice(0, alloc.target));
  }

  return sampledReviews.sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
}

export function estimateTokens(text: string): number {
  if (!text) return 0;
  const charCount = text.length;
  const wordCount = text.trim().split(/\s+/).filter(w => w.length > 0).length;
  return Math.max(Math.ceil(charCount / 4), Math.ceil(wordCount * 1.3));
}

export class LLMAnalyzer {
  private limiter = new LlamaRateLimiter();

  getLimiter(): LlamaRateLimiter {
    return this.limiter;
  }

  async analyze(reviews: Review[]): Promise<WeeklyPulseReport> {
    console.log(`Analyzing ${reviews.length} reviews...`);

    if (reviews.length === 0) {
      return {
        meta: {
          weekEnding: new Date().toISOString().split('T')[0],
          totalReviewsAnalyzed: 0
        },
        themes: [],
        verbatimQuotes: [],
        actionIdeas: [
          "No reviews were posted in the last 8-12 weeks. No weekly pulse was generated."
        ]
      };
    }

    const sampled = sampleReviews(reviews, 15);
    console.log(`Sampled down to ${sampled.length} reviews for analysis.`);

    const apiKey = process.env.GROQ_API_KEY || process.env.GEMINI_API_KEY;

    if (!apiKey) {
      console.log("No LLM API keys found. Running in self-contained fallback/mock mode.");
      return this.generateMockReport(sampled, reviews.length);
    }

    const isGemini = !!process.env.GEMINI_API_KEY && !process.env.GROQ_API_KEY;
    const url = isGemini 
      ? 'https://generativelanguage.googleapis.com/v1beta/openai/chat/completions'
      : 'https://api.groq.com/openai/v1/chat/completions';
    
    const model = isGemini ? 'gemini-1.5-flash' : 'llama-3.3-70b-versatile';

    const systemPrompt = `You are an expert product analyst. Your job is to analyze customer reviews for a mobile financial app and produce a Weekly Feedback Pulse report.

Classify the reviews into at most 5 predefined themes:
1. Account Verification & KYC (identity verification delays, account blocks, compliance friction)
2. Transfer Latency & Speed (delayed transactions, mismatched timing expectations)
3. Fees & Exchange Rates (currency conversion costs, deposit fees, pricing transparency)
4. Card Features & Usability (card freezing options, virtual/disposable card requests, app UI feedback)
5. Customer Support Access (unreachable human support, auto-responses, unresolved disputes)

You must output a JSON object with the following structure:
{
  "themes": [
    {
      "name": "One of the 5 predefined themes exactly",
      "sentiment": "Positive | Negative | Mixed",
      "percentage": 0.0
    }
  ],
  "verbatimQuotes": [
    // Exactly 3 verbatim, anonymized user quotes directly supporting the top themes.
    // Ensure you strip any PII (names, emails, phone numbers, location, IDs).
    // Do not invent or paraphrase the quote text other than PII redacting.
  ],
  "actionIdeas": [
    // Exactly 3 concrete action ideas addressing the major complaints in the top themes.
  ]
}

Constraints:
- You must output ONLY valid JSON. No markdown formatting around it, no explanations.
- Select the top 3 themes based on volume or severity from the reviews.
- The total words of the quotes, action ideas, and descriptions in the JSON must be concise (ensuring the final rendered report is <= 250 words).
- Verbatim quotes must match the text in the input reviews exactly (anonymized/redacted where PII was present). No hallucinated or invented text.`;

    const userPrompt = `Here are the customer reviews to analyze:
${JSON.stringify(sampled.map(r => ({ rating: r.rating, text: r.text })), null, 2)}`;

    const totalPromptText = systemPrompt + userPrompt;
    const estimatedInputTokens = estimateTokens(totalPromptText);
    const estimatedOutputTokens = 300;
    const totalEstimate = estimatedInputTokens + estimatedOutputTokens;

    console.log(`[LLM Call] Estimated tokens: ${totalEstimate} (Input: ${estimatedInputTokens}, Output: ${estimatedOutputTokens})`);

    await this.limiter.waitForQuota(totalEstimate);

    try {
      const response = await fetch(url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${apiKey}`
        },
        body: JSON.stringify({
          model,
          messages: [
            { role: 'system', content: systemPrompt },
            { role: 'user', content: userPrompt }
          ],
          temperature: 0.1,
          response_format: { type: 'json_object' }
        })
      });

      if (!response.ok) {
        throw new Error(`LLM API returned status ${response.status}: ${await response.text()}`);
      }

      const responseData = await response.json() as any;
      const content = responseData.choices[0].message.content;
      
      const actualTokens = responseData.usage?.total_tokens || totalEstimate;
      this.limiter.recordRequest(actualTokens);

      const parsed = JSON.parse(content);
      const validated = this.validateAndTruncateReport(parsed, sampled, reviews.length);
      return validated;

    } catch (error) {
      console.error("LLM API call failed, falling back to mock report:", error);
      return this.generateMockReport(sampled, reviews.length);
    }
  }

  private validateAndTruncateReport(parsed: any, sampled: Review[], totalCount: number): WeeklyPulseReport {
    const report: WeeklyPulseReport = {
      meta: {
        weekEnding: new Date().toISOString().split('T')[0],
        totalReviewsAnalyzed: totalCount
      },
      themes: [],
      verbatimQuotes: [],
      actionIdeas: []
    };

    if (Array.isArray(parsed.themes)) {
      const validThemes = [
        "Account Verification & KYC",
        "Transfer Latency & Speed",
        "Fees & Exchange Rates",
        "Card Features & Usability",
        "Customer Support Access"
      ];
      
      const filteredThemes = parsed.themes
        .filter((t: any) => t && typeof t.name === 'string' && validThemes.includes(t.name))
        .slice(0, 3);
      
      report.themes = filteredThemes.map((t: any) => ({
        name: t.name,
        sentiment: typeof t.sentiment === 'string' ? t.sentiment : 'Mixed',
        percentage: typeof t.percentage === 'number' ? t.percentage : 0
      }));
    }

    if (Array.isArray(parsed.verbatimQuotes)) {
      const rawQuotes = parsed.verbatimQuotes.filter((q: any) => typeof q === 'string') as string[];
      
      for (const quote of rawQuotes) {
        const found = sampled.some(r => {
          const cleanText = r.text.toLowerCase().replace(/[^a-z0-9]/g, '');
          const cleanQuote = quote.toLowerCase().replace(/[^a-z0-9]/g, '');
          return cleanText.includes(cleanQuote) || cleanQuote.includes(cleanText);
        });

        if (found) {
          report.verbatimQuotes.push(quote);
        } else {
          console.warn(`[Validation] Filtered out hallucinated quote: "${quote}"`);
        }
      }
    }

    while (report.verbatimQuotes.length < 3 && sampled.length > 0) {
      const backupQuote = sampled[report.verbatimQuotes.length % sampled.length].text;
      report.verbatimQuotes.push(backupQuote);
    }
    report.verbatimQuotes = report.verbatimQuotes.slice(0, 3);

    if (Array.isArray(parsed.actionIdeas)) {
      report.actionIdeas = parsed.actionIdeas
        .filter((a: any) => typeof a === 'string')
        .slice(0, 3);
    }

    const themeActionsMap: Record<string, string> = {
      "Account Verification & KYC": "Streamline document upload verification in onboarding flow to reduce verification latency.",
      "Transfer Latency & Speed": "Implement real-time status tracking and push notifications for withdrawal requests.",
      "Fees & Exchange Rates": "Provide clearer breakdowns of fees and exchange rates in-app before confirmation.",
      "Card Features & Usability": "Improve the card management UI and expand virtual card management features.",
      "Customer Support Access": "Optimize response times by routing complex disputes directly to specialized support agents."
    };

    while (report.actionIdeas.length < 3) {
      const themeName = report.themes[report.actionIdeas.length % Math.max(1, report.themes.length)]?.name || "Account Verification & KYC";
      report.actionIdeas.push(themeActionsMap[themeName]);
    }
    report.actionIdeas = report.actionIdeas.slice(0, 3);

    const reportText = [
      ...report.themes.map(t => `${t.name} ${t.sentiment}`),
      ...report.verbatimQuotes,
      ...report.actionIdeas
    ].join(' ');
    
    const wordCount = reportText.split(/\s+/).filter(w => w.length > 0).length;
    if (wordCount > 250) {
      console.warn(`[Validation] Report word count is ${wordCount}, truncating text to fit limit.`);
      report.actionIdeas = report.actionIdeas.map(a => {
        const words = a.split(/\s+/);
        if (words.length > 15) {
          return words.slice(0, 15).join(' ') + '...';
        }
        return a;
      });
    }

    return report;
  }

  private generateMockReport(sampled: Review[], totalCount: number): WeeklyPulseReport {
    const keywordMap = [
      { name: "Account Verification & KYC", keywords: ['kyc', 'verify', 'verification', 'identity', 'document', 'onboarding'] },
      { name: "Transfer Latency & Speed", keywords: ['transfer', 'delay', 'slow', 'speed', 'transaction', 'time', 'days'] },
      { name: "Fees & Exchange Rates", keywords: ['fee', 'rate', 'charge', 'cost', 'price', 'exchange'] },
      { name: "Card Features & Usability", keywords: ['card', 'freeze', 'virtual', 'ui', 'layout', 'app'] },
      { name: "Customer Support Access", keywords: ['support', 'customer', 'help', 'contact', 'chat', 'email'] }
    ];

    const themeCounts: Record<string, { count: number; ratings: number[] }> = {};
    for (const theme of keywordMap) {
      themeCounts[theme.name] = { count: 0, ratings: [] };
    }

    for (const review of sampled) {
      const textLower = review.text.toLowerCase();
      let matched = false;
      for (const theme of keywordMap) {
        if (theme.keywords.some(k => textLower.includes(k))) {
          themeCounts[theme.name].count++;
          themeCounts[theme.name].ratings.push(review.rating);
          matched = true;
        }
      }
      if (!matched) {
        themeCounts["Card Features & Usability"].count++;
        themeCounts["Card Features & Usability"].ratings.push(review.rating);
      }
    }

    const sortedThemes = Object.keys(themeCounts)
      .map(name => {
        const count = themeCounts[name].count;
        const ratings = themeCounts[name].ratings;
        const percentage = totalCount > 0 ? Math.round((count / sampled.length) * 100) : 0;
        const avgRating = ratings.length > 0 ? ratings.reduce((sum, r) => sum + r, 0) / ratings.length : 3;
        let sentiment = "Mixed";
        if (avgRating >= 4.0) sentiment = "Positive";
        else if (avgRating <= 2.5) sentiment = "Negative";

        return { name, percentage, sentiment, count };
      })
      .sort((a, b) => b.count - a.count)
      .slice(0, 3);

    const verbatimQuotes: string[] = [];
    for (const theme of sortedThemes) {
      const keywords = keywordMap.find(k => k.name === theme.name)?.keywords || [];
      const matchingReview = sampled.find(r => 
        keywords.some(k => r.text.toLowerCase().includes(k)) && 
        !verbatimQuotes.includes(r.text)
      ) || sampled[verbatimQuotes.length % sampled.length];
      
      if (matchingReview) {
        verbatimQuotes.push(matchingReview.text);
      }
    }

    while (verbatimQuotes.length < 3 && sampled.length > 0) {
      verbatimQuotes.push(sampled[verbatimQuotes.length % sampled.length].text);
    }

    const themeActionsMap: Record<string, string> = {
      "Account Verification & KYC": "Streamline document upload verification in onboarding flow to reduce verification latency.",
      "Transfer Latency & Speed": "Implement real-time status tracking and push notifications for withdrawal requests.",
      "Fees & Exchange Rates": "Provide clearer breakdowns of fees and exchange rates in-app before confirmation.",
      "Card Features & Usability": "Improve the card management UI and expand virtual card management features.",
      "Customer Support Access": "Optimize response times by routing complex disputes directly to specialized support agents."
    };

    const actionIdeas = sortedThemes.map(t => themeActionsMap[t.name]);

    return {
      meta: {
        weekEnding: new Date().toISOString().split('T')[0],
        totalReviewsAnalyzed: totalCount
      },
      themes: sortedThemes.map(t => ({ name: t.name, sentiment: t.sentiment, percentage: t.percentage })),
      verbatimQuotes: verbatimQuotes.slice(0, 3),
      actionIdeas: actionIdeas.slice(0, 3)
    };
  }
}
