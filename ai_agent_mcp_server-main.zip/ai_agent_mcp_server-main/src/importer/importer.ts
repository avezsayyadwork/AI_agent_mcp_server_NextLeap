import fs from 'fs';
import { z } from 'zod';

export const ReviewSchema = z.object({
  source: z.enum(['App Store', 'Play Store']),
  rating: z.number().min(1).max(5),
  title: z.string().optional(),
  text: z.string()
    .min(1, "Review text cannot be empty")
    .refine(
      (text) => text.trim().split(/\s+/).filter(w => w.length > 0).length >= 8,
      { message: "Review text must be at least 8 words long" }
    )
    .refine(
      (text) => !/[\p{Emoji_Presentation}\p{Extended_Pictographic}]/u.test(text),
      { message: "Review text must not contain emojis" }
    )
    .refine(
      (text) => !/[\u0900-\u097F]/.test(text),
      { message: "Review text must not contain Devanagari (Hindi) characters" }
    ),
  date: z.string().refine((val) => !isNaN(Date.parse(val)), {
    message: "Invalid date format",
  }),
  version: z.string().optional()
});

export type Review = z.infer<typeof ReviewSchema>;

export class ReviewImporter {
  /**
   * Imports reviews from a JSON file, validates them against the schema,
   * and returns only the valid reviews while logging warnings for invalid ones.
   */
  importReviews(filePath: string): Review[] {
    console.log(`Importing reviews from: ${filePath}`);
    
    if (!fs.existsSync(filePath)) {
      throw new Error(`File not found: ${filePath}`);
    }
    
    const fileContent = fs.readFileSync(filePath, 'utf-8');
    let rawData: unknown;
    
    try {
      rawData = JSON.parse(fileContent);
    } catch (error) {
      throw new Error(`Failed to parse JSON content from ${filePath}: ${(error as Error).message}`);
    }
    
    if (!Array.isArray(rawData)) {
      throw new Error(`Invalid JSON format: Expected an array of reviews at root.`);
    }
    
    const validReviews: Review[] = [];
    
    rawData.forEach((item, index) => {
      const result = ReviewSchema.safeParse(item);
      if (result.success) {
        validReviews.push(result.data);
      } else {
        console.warn(
          `[Validation Warning] Review at index ${index} was rejected. Errors:`,
          result.error.format()
        );
      }
    });
    
    console.log(`Import summary: ${validReviews.length} valid reviews imported (${rawData.length - validReviews.length} rejected).`);
    return validReviews;
  }

  /**
   * Filters reviews to keep only those within the last N weeks relative to a reference date.
   */
  filterReviewsByWeeks(reviews: Review[], weeks: number, referenceDate: Date = new Date()): Review[] {
    const cutoffTime = referenceDate.getTime() - (weeks * 7 * 24 * 60 * 60 * 1000);
    
    const filtered = reviews.filter(review => {
      const reviewTime = new Date(review.date).getTime();
      return reviewTime >= cutoffTime && reviewTime <= referenceDate.getTime();
    });
    
    console.log(`Filter summary: Retained ${filtered.length} of ${reviews.length} reviews from the last ${weeks} weeks.`);
    return filtered;
  }
}
