import { ReviewImporter } from '../importer/importer.js';
import { PiiScrubber } from '../scrubber/scrubber.js';
import { LLMAnalyzer } from '../analyzer/analyzer.js';
import { McpClientBridge } from '../mcp/mcpClient.js';
import fs from 'fs';
import path from 'path';

type WeeklyPulseLike = {
  meta: { weekEnding: string; totalReviewsAnalyzed?: number };
  themes: Array<{ name: string; sentiment: string; percentage: number }>;
  verbatimQuotes: string[];
  actionIdeas: string[];
};

function sanitizeReport(report: WeeklyPulseLike): WeeklyPulseLike {
  const sanitizedThemes = (report.themes || [])
    .filter(theme => theme && typeof theme.name === 'string')
    .slice(0, 3)
    .map(theme => ({
      ...theme,
      name: theme.name,
      sentiment: typeof theme.sentiment === 'string' ? theme.sentiment : 'Mixed',
      percentage: typeof theme.percentage === 'number' ? Math.min(100, Math.max(0, theme.percentage)) : 0
    }));

  const sanitizedQuotes = (report.verbatimQuotes || [])
    .filter((quote): quote is string => typeof quote === 'string')
    .map(quote => quote.replace(/\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b/gi, '[REDACTED_EMAIL]'))
    .map(quote => quote.replace(/https?:\/\/[^\s]+/g, '[REDACTED_LINK]'))
    .slice(0, 3);

  const sanitizedActions = (report.actionIdeas || [])
    .filter((action): action is string => typeof action === 'string')
    .map(action => action.replace(/\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b/gi, '[REDACTED_EMAIL]'))
    .slice(0, 3);

  const compacted = {
    ...report,
    meta: {
      ...report.meta,
      weekEnding: report.meta?.weekEnding || new Date().toISOString().split('T')[0]
    },
    themes: sanitizedThemes,
    verbatimQuotes: sanitizedQuotes,
    actionIdeas: sanitizedActions
  };

  const text = [
    ...compacted.themes.map(theme => `${theme.name} ${theme.sentiment}`),
    ...compacted.verbatimQuotes,
    ...compacted.actionIdeas
  ].join(' ');

  const wordCount = text.split(/\s+/).filter(Boolean).length;

  if (wordCount > 250) {
    const trimmedActions = compacted.actionIdeas.map(action => action.split(/\s+/).slice(0, 12).join(' '));
    const trimmedQuotes = compacted.verbatimQuotes.map(quote => quote.split(/\s+/).slice(0, 10).join(' '));
    return {
      ...compacted,
      verbatimQuotes: trimmedQuotes,
      actionIdeas: trimmedActions
    };
  }

  return compacted;
}

function formatWeeklyPulseDocument(report: WeeklyPulseLike): string {
  const themeSummary = report.themes.length > 0
    ? report.themes.map(theme => `${theme.name}: ${theme.sentiment} (${theme.percentage}%)`).join('; ')
    : 'No major themes detected.';

  const quoteSummary = report.verbatimQuotes.length > 0
    ? report.verbatimQuotes.map(quote => `"${quote}"`).join(' | ')
    : 'No supporting quotes available.';

  const actionSummary = report.actionIdeas.length > 0
    ? report.actionIdeas.join(' | ')
    : 'No action ideas available.';

  return [
    `# Weekly Feedback Pulse - ${report.meta.weekEnding}`,
    '',
    '## Top Themes',
    `- ${themeSummary}`,
    '',
    '## Supporting Quotes',
    `- ${quoteSummary}`,
    '',
    '## Recommended Actions',
    `- ${actionSummary}`,
    '',
    '## Summary',
    `Analyzed ${report.meta.weekEnding} feedback and prepared a compact weekly pulse summary.`
  ].join('\n');
}

function formatWeeklyPulseEmail(report: WeeklyPulseLike): string {
  const themeSummary = report.themes.length > 0
    ? report.themes.slice(0, 3).map(theme => `${theme.name} (${theme.sentiment})`).join(', ')
    : 'No major themes detected';

  return [
    `Weekly Feedback Pulse - ${report.meta.weekEnding}`,
    '',
    `Top themes: ${themeSummary}`,
    '',
    'Please review the attached Google Doc for the full summary and recommended actions.'
  ].join('\n');
}

export class PipelineOrchestrator {
  private importer = new ReviewImporter();
  private scrubber = new PiiScrubber();
  private analyzer = new LLMAnalyzer();
  private mcpClient = new McpClientBridge();

  async run(reviewFilePath: string, docsServerPath: string, gmailServerPath: string, recipientEmail: string): Promise<void> {
    console.log('Starting E2E Pulse Pipeline run...');

    const targetFolderId = process.env.GOOGLE_DRIVE_FOLDER_ID || process.env.GOOGLE_DOCS_FOLDER_ID;
    const targetDocumentUrl = process.env.GOOGLE_DOC_URL || process.env.GOOGLE_DOC_ID;

    // 1. Ingest reviews
    const rawReviews = this.importer.importReviews(reviewFilePath);

    // 2. Scrub PII
    const cleanReviews = this.scrubber.scrubReviews(rawReviews);

    // 3. Cluster and analyze
    const report = await this.analyzer.analyze(cleanReviews);
    const compliantReport = sanitizeReport(report);

    // Write local copy to pulse_draft.json
    const outputPath = path.resolve('pulse_draft.json');
    fs.writeFileSync(outputPath, JSON.stringify(compliantReport, null, 2), 'utf-8');
    console.log(`Local weekly pulse report draft written to: ${outputPath}`);

    try {
      // 4. Connect to MCP Servers with retry for transient failures
      let connectedDocs = false;
      let connectedGmail = false;
      for (let attempt = 0; attempt < 2; attempt += 1) {
        try {
          await this.mcpClient.connectToDocs(docsServerPath);
          connectedDocs = true;
          break;
        } catch (error) {
          console.warn(`Google Docs connection attempt ${attempt + 1} failed:`, error);
        }
      }

      for (let attempt = 0; attempt < 2; attempt += 1) {
        try {
          await this.mcpClient.connectToGmail(gmailServerPath);
          connectedGmail = true;
          break;
        } catch (error) {
          console.warn(`Gmail connection attempt ${attempt + 1} failed:`, error);
        }
      }

      const docContent = formatWeeklyPulseDocument(compliantReport);
      const emailBody = formatWeeklyPulseEmail(compliantReport);

      // 5. Create Google Doc
      const docId = targetDocumentUrl
        ? await this.mcpClient.createDoc(
            `Weekly Feedback Pulse - ${compliantReport.meta.weekEnding}`,
            docContent,
            {
              folderId: targetFolderId,
              documentUrl: targetDocumentUrl,
              documentId: targetDocumentUrl.startsWith('http') ? undefined : targetDocumentUrl
            }
          )
        : targetFolderId
          ? await this.mcpClient.createDoc(
              `Weekly Feedback Pulse - ${compliantReport.meta.weekEnding}`,
              docContent,
              { folderId: targetFolderId }
            )
          : await this.mcpClient.createDoc(
              `Weekly Feedback Pulse - ${compliantReport.meta.weekEnding}`,
              docContent
            );

      // 6. Create Gmail Draft
      const draftId = await this.mcpClient.createDraft(
        recipientEmail,
        `Weekly Feedback Pulse - ${compliantReport.meta.weekEnding}`,
        `Here is the link to the Google Doc: https://docs.google.com/document/d/${docId}/edit\n\n${emailBody}`
      );

      console.log(`Pipeline run completed successfully. Doc ID: ${docId}, Draft ID: ${draftId}`);
      console.log(`MCP connection status: docs=${connectedDocs}, gmail=${connectedGmail}`);
    } finally {
      await this.mcpClient.close();
    }
  }
}
