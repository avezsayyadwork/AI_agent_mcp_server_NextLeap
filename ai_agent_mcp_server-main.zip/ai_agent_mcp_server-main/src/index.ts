import dotenv from 'dotenv';
import { PipelineOrchestrator } from './orchestrator/orchestrator.js';
import http from 'http';
import path from 'path';
import { pathToFileURL } from 'url';
import fs from 'fs';
import { McpClientBridge } from './mcp/mcpClient.js';

dotenv.config();

console.log('Mobile Store Feedback Weekly Pulse Pipeline Initialized.');

export interface ServerOptions {
  port?: number | string;
  host?: string;
  autoRunPipeline?: boolean;
}

async function runPipeline(): Promise<void> {
  const orchestrator = new PipelineOrchestrator();

  const reviewFilePath = path.resolve('data/normalized_reviews.json');
  const docsServerPath = process.env.MCP_DOCS_SERVER_PATH || '';
  const gmailServerPath = process.env.MCP_GMAIL_SERVER_PATH || '';
  const recipientEmail = process.env.RECIPIENT_EMAIL || 'your_email@example.com';

  console.log(`Running pipeline with review file: ${reviewFilePath}`);
  await orchestrator.run(reviewFilePath, docsServerPath, gmailServerPath, recipientEmail);
}

export async function startServer(options: ServerOptions = {}): Promise<http.Server> {
  const host = options.host ?? process.env.HOST ?? '0.0.0.0';
  const port = Number(options.port ?? process.env.PORT ?? 3000);
  const autoRunPipeline = options.autoRunPipeline ?? process.env.RUN_PIPELINE_ON_START === 'true';

  const server = http.createServer((req, res) => {
    const requestUrl = req.url ? new URL(req.url, `http://${req.headers.host ?? 'localhost'}`) : null;

    if (!requestUrl) {
      res.writeHead(400, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: 'Invalid request URL' }));
      return;
    }

    if (requestUrl.pathname === '/health') {
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ status: 'ok', service: 'mobile-store-feedback-weekly-pulse' }));
      return;
    }

    if (requestUrl.pathname === '/' || requestUrl.pathname === '/index.html') {
      try {
        const filePath = path.resolve('pulse_dashboard_UI/code.html');
        const content = fs.readFileSync(filePath, 'utf8');
        res.writeHead(200, { 'Content-Type': 'text/html' });
        res.end(content);
      } catch (err) {
        res.writeHead(500, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: 'Failed to read code.html dashboard' }));
      }
      return;
    }

    if (requestUrl.pathname === '/screen.png') {
      try {
        const filePath = path.resolve('pulse_dashboard_UI/screen.png');
        const content = fs.readFileSync(filePath);
        res.writeHead(200, { 'Content-Type': 'image/png' });
        res.end(content);
      } catch (err) {
        res.writeHead(404, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: 'File not found' }));
      }
      return;
    }

    if (requestUrl.pathname === '/api/data') {
      let pulseDraft = null;
      try {
        pulseDraft = JSON.parse(fs.readFileSync(path.resolve('pulse_draft.json'), 'utf8'));
      } catch (err) {}

      let reviews = [];
      try {
        reviews = JSON.parse(fs.readFileSync(path.resolve('data/normalized_reviews.json'), 'utf8'));
      } catch (err) {}

      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({
        config: {
          googleDocId: process.env.GOOGLE_DOC_ID || '',
          googleDocUrl: process.env.GOOGLE_DOC_URL || '',
          recipientEmail: process.env.RECIPIENT_EMAIL || ''
        },
        pulseDraft,
        reviews
      }));
      return;
    }

    if (requestUrl.pathname === '/api/run' && req.method === 'POST') {
      const orchestrator = new PipelineOrchestrator();
      const reviewFilePath = path.resolve('data/normalized_reviews.json');
      const docsServerPath = process.env.MCP_DOCS_SERVER_PATH || '';
      const gmailServerPath = process.env.MCP_GMAIL_SERVER_PATH || '';
      const recipientEmail = process.env.RECIPIENT_EMAIL || 'your_email@example.com';

      orchestrator.run(reviewFilePath, docsServerPath, gmailServerPath, recipientEmail)
        .then(() => {
          let pulseDraft = null;
          try {
            pulseDraft = JSON.parse(fs.readFileSync(path.resolve('pulse_draft.json'), 'utf8'));
          } catch (err) {}
          res.writeHead(200, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ success: true, pulseDraft }));
        })
        .catch((err: any) => {
          console.error('API Run Pipeline Failed:', err);
          res.writeHead(500, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ error: err.message || 'Pipeline run failed' }));
        });
      return;
    }

    if (requestUrl.pathname === '/api/publish' && req.method === 'POST') {
      let bodyData = '';
      req.on('data', chunk => { bodyData += chunk; });
      req.on('end', () => {
        try {
          const parsed = JSON.parse(bodyData || '{}');
          const docContent = parsed.content;
          const title = parsed.title || `Weekly Feedback Pulse - ${new Date().toISOString().split('T')[0]}`;
          
          const docsServerPath = process.env.MCP_DOCS_SERVER_PATH || '';
          const targetFolderId = process.env.GOOGLE_DRIVE_FOLDER_ID || process.env.GOOGLE_DOCS_FOLDER_ID;
          const targetDocumentUrl = process.env.GOOGLE_DOC_URL || process.env.GOOGLE_DOC_ID;

          const mcpClient = new McpClientBridge();
          mcpClient.connectToDocs(docsServerPath)
            .then(async () => {
              const docId = targetDocumentUrl
                ? await mcpClient.createDoc(title, docContent, {
                    folderId: targetFolderId,
                    documentUrl: targetDocumentUrl,
                    documentId: targetDocumentUrl.startsWith('http') ? undefined : targetDocumentUrl
                  })
                : await mcpClient.createDoc(title, docContent);
              await mcpClient.close();
              res.writeHead(200, { 'Content-Type': 'application/json' });
              res.end(JSON.stringify({ success: true, docId }));
            })
            .catch((innerErr: any) => {
              res.writeHead(500, { 'Content-Type': 'application/json' });
              res.end(JSON.stringify({ error: innerErr.message || 'Publish failed' }));
            });
        } catch (err: any) {
          res.writeHead(500, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ error: err.message || 'Request parsing failed' }));
        }
      });
      return;
    }

    if (requestUrl.pathname === '/api/gmail-draft' && req.method === 'POST') {
      let bodyData = '';
      req.on('data', chunk => { bodyData += chunk; });
      req.on('end', () => {
        try {
          const parsed = JSON.parse(bodyData || '{}');
          const to = parsed.to || process.env.RECIPIENT_EMAIL || 'your_email@example.com';
          const subject = parsed.subject || 'Weekly Feedback Pulse';
          const body = parsed.body || '';

          const gmailServerPath = process.env.MCP_GMAIL_SERVER_PATH || '';
          const mcpClient = new McpClientBridge();
          mcpClient.connectToGmail(gmailServerPath)
            .then(async () => {
              const draftId = await mcpClient.createDraft(to, subject, body);
              await mcpClient.close();
              res.writeHead(200, { 'Content-Type': 'application/json' });
              res.end(JSON.stringify({ success: true, draftId }));
            })
            .catch((innerErr: any) => {
              res.writeHead(500, { 'Content-Type': 'application/json' });
              res.end(JSON.stringify({ error: innerErr.message || 'Draft creation failed' }));
            });
        } catch (err: any) {
          res.writeHead(500, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ error: err.message || 'Request parsing failed' }));
        }
      });
      return;
    }

    if (requestUrl.pathname === '/api/gmail-send' && req.method === 'POST') {
      let bodyData = '';
      req.on('data', chunk => { bodyData += chunk; });
      req.on('end', () => {
        try {
          const parsed = JSON.parse(bodyData || '{}');
          const to = parsed.to || process.env.RECIPIENT_EMAIL || 'your_email@example.com';
          const subject = parsed.subject || 'Weekly Feedback Pulse';
          const body = parsed.body || '';

          const gmailServerPath = process.env.MCP_GMAIL_SERVER_PATH || '';
          const mcpClient = new McpClientBridge();
          mcpClient.connectToGmail(gmailServerPath)
            .then(async () => {
              const success = await mcpClient.sendEmail(to, subject, body);
              await mcpClient.close();
              res.writeHead(200, { 'Content-Type': 'application/json' });
              res.end(JSON.stringify({ success }));
            })
            .catch((innerErr: any) => {
              res.writeHead(500, { 'Content-Type': 'application/json' });
              res.end(JSON.stringify({ error: innerErr.message || 'Send failed' }));
            });
        } catch (err: any) {
          res.writeHead(500, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ error: err.message || 'Request parsing failed' }));
        }
      });
      return;
    }

    if (requestUrl.pathname === '/api/settings' && req.method === 'POST') {
      let bodyData = '';
      req.on('data', chunk => { bodyData += chunk; });
      req.on('end', () => {
        try {
          const parsed = JSON.parse(bodyData || '{}');
          const email = parsed.recipientEmail || '';
          const docUrl = parsed.googleDocUrl || '';

          const envPath = path.resolve('.env');
          let envContent = '';
          if (fs.existsSync(envPath)) {
            envContent = fs.readFileSync(envPath, 'utf8');
            
            // Replace RECIPIENT_EMAIL if exists, else append
            if (envContent.match(/^RECIPIENT_EMAIL=/m)) {
              envContent = envContent.replace(/^RECIPIENT_EMAIL=.*$/m, `RECIPIENT_EMAIL=${email}`);
            } else {
              envContent += `\nRECIPIENT_EMAIL=${email}`;
            }

            // Replace GOOGLE_DOC_URL if exists, else append
            if (envContent.match(/^GOOGLE_DOC_URL=/m)) {
              envContent = envContent.replace(/^GOOGLE_DOC_URL=.*$/m, `GOOGLE_DOC_URL=${docUrl}`);
            } else {
              envContent += `\nGOOGLE_DOC_URL=${docUrl}`;
            }
          } else {
            envContent = `RECIPIENT_EMAIL=${email}\nGOOGLE_DOC_URL=${docUrl}\n`;
          }

          fs.writeFileSync(envPath, envContent, 'utf8');
          process.env.RECIPIENT_EMAIL = email;
          process.env.GOOGLE_DOC_URL = docUrl;

          res.writeHead(200, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ success: true }));
        } catch (err: any) {
          res.writeHead(500, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ error: err.message || 'Failed to save settings' }));
        }
      });
      return;
    }

    res.writeHead(404, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ error: 'Not found' }));
  });

  await new Promise<void>((resolve, reject) => {
    server.once('error', reject);
    server.listen(port, host, () => resolve());
  });

  const address = server.address();
  const resolvedPort = address && typeof address !== 'string' ? address.port : port;
  console.log(`Deployment server listening on http://${host}:${resolvedPort}`);

  if (autoRunPipeline) {
    void runPipeline().catch(err => {
      console.error('Pipeline run failed:', err);
    });
  }

  return server;
}

export async function closeServer(server: http.Server): Promise<void> {
  await new Promise<void>((resolve, reject) => {
    server.close(err => (err ? reject(err) : resolve()));
  });
}

export async function main(): Promise<void> {
  const server = await startServer();

  const shutdown = async () => {
    console.log('Shutting down deployment server...');
    await closeServer(server);
    process.exit(0);
  };

  process.on('SIGINT', () => {
    void shutdown();
  });

  process.on('SIGTERM', () => {
    void shutdown();
  });
}

const isMainModule = process.argv[1] ? import.meta.url === pathToFileURL(process.argv[1]).href : false;

if (isMainModule) {
  void main().catch(err => {
    console.error('Deployment server failed to start:', err);
    process.exit(1);
  });
}
