import { Client } from '@modelcontextprotocol/sdk/client/index.js';
import { StdioClientTransport } from '@modelcontextprotocol/sdk/client/stdio.js';
import { StreamableHTTPClientTransport } from '@modelcontextprotocol/sdk/client/streamableHttp.js';
import { SSEClientTransport } from '@modelcontextprotocol/sdk/client/sse.js';

/**
 * Parses a command string into command and argument tokens.
 * Handles spaces and quotes (single or double) properly.
 */
export function parseCommandString(cmdStr: string): { command: string; args: string[] } {
  const tokens: string[] = [];
  let currentToken = '';
  let inQuotes = false;
  let quoteChar = '';

  for (let i = 0; i < cmdStr.length; i++) {
    const char = cmdStr[i];
    if ((char === '"' || char === "'") && (i === 0 || cmdStr[i - 1] !== '\\')) {
      if (inQuotes && char === quoteChar) {
        inQuotes = false;
      } else if (!inQuotes) {
        inQuotes = true;
        quoteChar = char;
      } else {
        currentToken += char;
      }
    } else if (/\s/.test(char) && !inQuotes) {
      if (currentToken.length > 0) {
        tokens.push(currentToken);
        currentToken = '';
      }
    } else {
      currentToken += char;
    }
  }
  if (currentToken.length > 0) {
    tokens.push(currentToken);
  }

  if (tokens.length === 0) {
    throw new Error('Empty command path');
  }

  return {
    command: tokens[0],
    args: tokens.slice(1)
  };
}

export class McpClientBridge {
  private docsClient: Client | null = null;
  private gmailClient: Client | null = null;
  private docsTransport: StdioClientTransport | StreamableHTTPClientTransport | SSEClientTransport | null = null;
  private gmailTransport: StdioClientTransport | StreamableHTTPClientTransport | SSEClientTransport | null = null;

  private createTransport(server: string) {
    const trimmed = server.trim();
    if (!trimmed) {
      return null;
    }

    if (/^https?:\/\//i.test(trimmed)) {
      if (trimmed.endsWith('/sse') || trimmed.includes('/sse?')) {
        return new SSEClientTransport(new URL(trimmed));
      }
      return new StreamableHTTPClientTransport(new URL(trimmed));
    }

    const { command, args } = parseCommandString(trimmed);
    return new StdioClientTransport({
      command,
      args,
      stderr: 'inherit'
    });
  }

  private createSseTransport(server: string) {
    const trimmed = server.trim();
    if (!trimmed || !/^https?:\/\//i.test(trimmed)) {
      return null;
    }

    return new SSEClientTransport(new URL(trimmed));
  }

  async connectToDocs(serverPath: string): Promise<void> {
    if (!serverPath || serverPath.trim() === '') {
      console.log('No Google Docs MCP server path configured. Running Google Docs in mock/simulation mode.');
      return;
    }

    try {
      console.log(`Connecting to Google Docs MCP server at: ${serverPath}`);
      this.docsTransport = this.createTransport(serverPath);

      if (!this.docsTransport) {
        throw new Error('Unable to create Google Docs transport');
      }

      this.docsClient = new Client(
        { name: 'pulse-docs-client', version: '1.0.0' },
        { capabilities: {} }
      );

      await this.docsClient.connect(this.docsTransport);
      console.log('Successfully connected to Google Docs MCP server.');
    } catch (error) {
      if (/^https?:\/\//i.test(serverPath)) {
        try {
          const fallbackTransport = this.createSseTransport(serverPath);
          if (fallbackTransport) {
            this.docsTransport = fallbackTransport;
            this.docsClient = new Client(
              { name: 'pulse-docs-client', version: '1.0.0' },
              { capabilities: {} }
            );
            await this.docsClient.connect(this.docsTransport);
            console.log('Successfully connected to Google Docs MCP server using SSE fallback.');
            return;
          }
        } catch (fallbackError) {
          console.error('SSE fallback also failed:', fallbackError);
        }
      }

      console.error('Failed to connect to Google Docs MCP server, falling back to mock mode:', error);
      this.docsClient = null;
      this.docsTransport = null;
    }
  }

  async connectToGmail(serverPath: string): Promise<void> {
    if (!serverPath || serverPath.trim() === '') {
      console.log('No Gmail MCP server path configured. Running Gmail in mock/simulation mode.');
      return;
    }

    try {
      console.log(`Connecting to Gmail MCP server at: ${serverPath}`);
      this.gmailTransport = this.createTransport(serverPath);

      if (!this.gmailTransport) {
        throw new Error('Unable to create Gmail transport');
      }

      this.gmailClient = new Client(
        { name: 'pulse-gmail-client', version: '1.0.0' },
        { capabilities: {} }
      );

      await this.gmailClient.connect(this.gmailTransport);
      console.log('Successfully connected to Gmail MCP server.');
    } catch (error) {
      if (/^https?:\/\//i.test(serverPath)) {
        try {
          const fallbackTransport = this.createSseTransport(serverPath);
          if (fallbackTransport) {
            this.gmailTransport = fallbackTransport;
            this.gmailClient = new Client(
              { name: 'pulse-gmail-client', version: '1.0.0' },
              { capabilities: {} }
            );
            await this.gmailClient.connect(this.gmailTransport);
            console.log('Successfully connected to Gmail MCP server using SSE fallback.');
            return;
          }
        } catch (fallbackError) {
          console.error('SSE fallback also failed:', fallbackError);
        }
      }

      console.error('Failed to connect to Gmail MCP server, falling back to mock mode:', error);
      this.gmailClient = null;
      this.gmailTransport = null;
    }
  }

  async createDoc(title: string, content: string, options?: { folderId?: string; documentUrl?: string; documentId?: string }): Promise<string> {
    if (!this.docsClient) {
      console.log(`[Mock Google Docs] Creating document: "${title}"`);
      return 'mock-doc-id-123';
    }

    try {
      const toolList = await this.docsClient.listTools();
      let docId = options?.documentId || '';
      if (!docId && options?.documentUrl) {
        const match = options.documentUrl.match(/\/document\/d\/([a-zA-Z0-9-_]+)/);
        docId = match ? match[1] : '';
      }

      if (docId) {
        console.log(`Using existing Google Doc ID: ${docId}`);
      } else {
        const createTool = toolList.tools.find(t => /create_?doc/i.test(t.name));
        if (!createTool) {
          throw new Error('Google Docs MCP server does not expose a create document tool');
        }

        const createArguments: Record<string, any> = { title };
        if (options?.folderId) {
          createArguments.folderId = options.folderId;
        }

        console.log(`Calling Google Docs tool: ${createTool.name}`);
        const createResult = await this.docsClient.callTool({
          name: createTool.name,
          arguments: createArguments
        }) as any;

        if (createResult.isError) {
          throw new Error(`Google Docs creation tool failed: ${JSON.stringify(createResult.content)}`);
        }

        const text = createResult.content
          .map((c: any) => c.type === 'text' ? c.text : '')
          .join(' ');

        const docIdMatch = text.match(/\/document\/d\/([a-zA-Z0-9-_]+)/) || text.match(/\b([a-zA-Z0-9-_]{44})\b/);
        docId = docIdMatch ? docIdMatch[1] : '';

        if (!docId) {
          throw new Error(`Failed to extract documentId from response: ${text}`);
        }

        console.log(`Created document with ID: ${docId}`);
      }

      // Now append content to the document
      const appendTool = toolList.tools.find(t => 
        /append_?text/i.test(t.name) || /insert_?text/i.test(t.name) || /write/i.test(t.name)
      );

      if (appendTool) {
        console.log(`Calling Google Docs tool: ${appendTool.name}`);
        const properties = appendTool.inputSchema.properties || {};
        const docIdParamName = Object.keys(properties).find(k => /doc/i.test(k) || /id/i.test(k)) || 'documentId';
        const textParamName = Object.keys(properties).find(k => /text/i.test(k) || /content/i.test(k) || /body/i.test(k)) || 'text';

        const appendResult = await this.docsClient.callTool({
          name: appendTool.name,
          arguments: {
            [docIdParamName]: docId,
            [textParamName]: content
          }
        });

        if (appendResult.isError) {
          console.warn(`Failed to append content to document: ${JSON.stringify(appendResult.content)}`);
        } else {
          console.log(`Successfully appended content to Google Doc ${docId}`);
        }
      } else {
        console.warn('Could not find an append or insert text tool in Google Docs MCP server.');
      }

      return docId;
    } catch (error) {
      console.error('Error during Google Doc creation, falling back to simulation:', error);
      return 'mock-doc-id-123';
    }
  }

  async createDraft(to: string, subject: string, body: string): Promise<string> {
    if (!this.gmailClient) {
      console.log(`[Mock Gmail] Creating email draft to: ${to}`);
      return 'mock-draft-id-456';
    }

    try {
      const toolList = await this.gmailClient.listTools();
      const draftTool = toolList.tools.find(t => /create_?draft/i.test(t.name));
      if (!draftTool) {
        throw new Error('Gmail MCP server does not expose a create draft tool');
      }

      const properties = draftTool.inputSchema.properties || {};
      const toParam = Object.keys(properties).find(k => /^to$/i.test(k)) || 'to';
      const subjectParam = Object.keys(properties).find(k => /subject/i.test(k)) || 'subject';
      const bodyParam = Object.keys(properties).find(k => /body/i.test(k) || /text/i.test(k) || /content/i.test(k)) || 'body';

      const toSchema = properties[toParam] as any;
      const toValue = (toSchema && toSchema.type === 'array') ? [to] : to;

      console.log(`Calling Gmail tool: ${draftTool.name}`);
      const result = await this.gmailClient.callTool({
        name: draftTool.name,
        arguments: {
          [toParam]: toValue,
          [subjectParam]: subject,
          [bodyParam]: body
        }
      }) as any;

      if (result.isError) {
        throw new Error(`Gmail draft creation failed: ${JSON.stringify(result.content)}`);
      }

      const text = result.content
        .map((c: any) => c.type === 'text' ? c.text : '')
        .join(' ');

      const draftIdMatch = text.match(/drafts?\/([a-zA-Z0-9-_]+)/) || text.match(/\b([a-zA-Z0-9-_]{10,})\b/);
      const draftId = draftIdMatch ? draftIdMatch[1] : 'mock-draft-id-456';

      console.log(`Created draft with ID: ${draftId}`);
      return draftId;
    } catch (error) {
      console.error('Error during Gmail draft creation, falling back to simulation:', error);
      return 'mock-draft-id-456';
    }
  }

  async sendEmail(to: string, subject: string, body: string): Promise<boolean> {
    if (!this.gmailClient) {
      console.log(`[Mock Gmail] Sending email to: ${to}`);
      return true;
    }

    try {
      const toolList = await this.gmailClient.listTools();
      const sendTool = toolList.tools.find(t => /send_?email/i.test(t.name));
      if (!sendTool) {
        throw new Error('Gmail MCP server does not expose a send email tool');
      }

      console.log(`Calling Gmail tool: ${sendTool.name}`);
      const result = await this.gmailClient.callTool({
        name: sendTool.name,
        arguments: {
          to,
          subject,
          body
        }
      }) as any;

      if (result.isError) {
        throw new Error(`Gmail send email failed: ${JSON.stringify(result.content)}`);
      }

      console.log('Email sent successfully via Gmail MCP server.');
      return true;
    } catch (error) {
      console.error('Error during Gmail email sending:', error);
      return false;
    }
  }

  async close(): Promise<void> {
    if (this.docsTransport) {
      console.log('Closing Google Docs MCP client transport...');
      try {
        await this.docsTransport.close();
      } catch (err) {
        console.error('Error closing Google Docs transport:', err);
      }
      this.docsTransport = null;
    }
    if (this.gmailTransport) {
      console.log('Closing Gmail MCP client transport...');
      try {
        await this.gmailTransport.close();
      } catch (err) {
        console.error('Error closing Gmail transport:', err);
      }
      this.gmailTransport = null;
    }
    this.docsClient = null;
    this.gmailClient = null;
  }
}
