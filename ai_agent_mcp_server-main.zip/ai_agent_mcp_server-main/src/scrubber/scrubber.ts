import { Review } from '../importer/importer.js';

export class PiiScrubber {
  private static readonly EMAIL_REGEX = /[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/g;
  
  // Matches UUIDs
  private static readonly UUID_REGEX = /\b[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}\b/g;
  
  // Matches long numeric/alphanumeric IDs (typically 11+ digits or 12+ hex characters, e.g. device ID, transaction ID, customer ID)
  private static readonly SYSTEM_ID_REGEX = /\b\d{11,}\b|\b[a-fA-F0-9]{12,}\b/g;
  
  // Matches IPv4 and IPv6
  private static readonly IP_REGEX = /\b(?:\d{1,3}\.){3}\d{1,3}\b|\b(?:[0-9a-fA-F]{1,4}:){1,7}[0-9a-fA-F]{1,4}\b/g;
  
  // Matches social handles / usernames starting with @
  private static readonly USERNAME_REGEX = /@[a-zA-Z0-9_.-]+/g;

  // Matches phone numbers in common formats, e.g. +1-234-567-8901, (123) 456-7890, 1234567890
  private static readonly PHONE_REGEX = /(?:\+\d{1,3}[-.\s]?)?\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4,6}/g;

  private static readonly WORD_TO_DIGIT_MAP: Record<string, string> = {
    zero: '0', one: '1', two: '2', three: '3', four: '4',
    five: '5', six: '6', seven: '7', eight: '8', nine: '9'
  };

  scrubText(text: string): string {
    if (!text) return '';

    let scrubbed = text;

    // 1. Scrub emails
    scrubbed = scrubbed.replace(PiiScrubber.EMAIL_REGEX, '[REDACTED_EMAIL]');

    // 2. Scrub UUIDs
    scrubbed = scrubbed.replace(PiiScrubber.UUID_REGEX, '[REDACTED_ID]');

    // 3. Scrub IP addresses
    scrubbed = scrubbed.replace(PiiScrubber.IP_REGEX, '[REDACTED_IP]');

    // 4. Scrub usernames
    scrubbed = scrubbed.replace(PiiScrubber.USERNAME_REGEX, '[REDACTED_USER]');

    // 5. Scrub system IDs (run before phone numbers to redact 11+ digits as IDs)
    scrubbed = scrubbed.replace(PiiScrubber.SYSTEM_ID_REGEX, '[REDACTED_ID]');

    // 6. Scrub sneaky/word-based phone numbers
    const tokenRegex = /\b(?:zero|one|two|three|four|five|six|seven|eight|nine|\d+)\b/gi;
    let match;
    const sneakyMatches: { start: number; end: number; text: string }[] = [];
    
    // Find all contiguous sequences of number tokens
    const tokens: { start: number; end: number; val: string }[] = [];
    const regex = new RegExp(tokenRegex);
    while ((match = regex.exec(scrubbed)) !== null) {
      tokens.push({
        start: match.index,
        end: regex.lastIndex,
        val: match[0]
      });
    }

    // Now group adjacent tokens (separated by at most spaces, tabs, or hyphens)
    let i = 0;
    while (i < tokens.length) {
      let j = i;
      while (j + 1 < tokens.length) {
        const gap = scrubbed.slice(tokens[j].end, tokens[j + 1].start);
        if (/^[-.\s]*$/.test(gap)) {
          j++;
        } else {
          break;
        }
      }
      // If we have a sequence of at least 7 number tokens, it's likely a phone number or ID
      if (j - i + 1 >= 7) {
        sneakyMatches.push({
          start: tokens[i].start,
          end: tokens[j].end,
          text: scrubbed.slice(tokens[i].start, tokens[j].end)
        });
      }
      i = j + 1;
    }

    // Replace the sneaky matches from end to start to avoid shifting indices
    for (let k = sneakyMatches.length - 1; k >= 0; k--) {
      const matchItem = sneakyMatches[k];
      scrubbed = scrubbed.slice(0, matchItem.start) + '[REDACTED_PHONE]' + scrubbed.slice(matchItem.end);
    }

    // 6. Scrub normal phone numbers
    scrubbed = scrubbed.replace(PiiScrubber.PHONE_REGEX, '[REDACTED_PHONE]');

    // 7. Scrub system IDs
    scrubbed = scrubbed.replace(PiiScrubber.SYSTEM_ID_REGEX, '[REDACTED_ID]');

    return scrubbed;
  }

  scrubReview(review: Review): Review {
    return {
      ...review,
      title: review.title ? this.scrubText(review.title) : review.title,
      text: this.scrubText(review.text)
    };
  }

  scrubReviews(reviews: Review[]): Review[] {
    return reviews.map(r => this.scrubReview(r));
  }
}
